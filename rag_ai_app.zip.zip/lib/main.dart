import 'dart:convert';
import 'dart:html' as html; // استفاده از ابزار خود مرورگر برای آپلود
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        scaffoldBackgroundColor: const Color(0xFFF5F6FA), 
      ),
      home: const ChatScreen(),
    );
  }
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  String _chatResponse = "سلام! من دستیار آموزشی شما هستم. ابتدا یک جزوه آپلود کنید، سپس سوال خود را بپرسید.";
  bool _isLoading = false;

  // ⚠️ IP کامپیوتر خودت رو اینجا بذار!
  final String baseUrl = "http://10.243.246.180:8000"; 

  Future<void> _sendMessage() async {
    if (_controller.text.isEmpty) return;
    setState(() {
      _isLoading = true;
      _chatResponse = "در حال فکر کردن...";
    });

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/chat'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"question": _controller.text}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(utf8.decode(response.bodyBytes));
        setState(() {
          _chatResponse = data['answer'];
        });
      } else {
        setState(() => _chatResponse = "خطا در پاسخ سرور.");
      }
    } catch (e) {
      setState(() => _chatResponse = "خطا در ارتباط با سرور. مطمئن شو سرور پایتون روشنه.");
    } finally {
      setState(() => _isLoading = false);
      _controller.clear();
    }
  }

  Future<void> _pickAndUploadFile() async {
    // روش اختصاصی و بدون ارور برای وب (بدون نیاز به پکیج اضافی)
    final html.FileUploadInputElement uploadInput = html.FileUploadInputElement();
    uploadInput.accept = '.pdf';
    uploadInput.click();

    uploadInput.onChange.listen((e) async {
      final file = uploadInput.files!.first;
      final reader = html.FileReader();
      
      setState(() {
        _isLoading = true;
        _chatResponse = "در حال پردازش جزوه...";
      });

      reader.readAsArrayBuffer(file);
      reader.onLoadEnd.listen((e) async {
        final bytes = reader.result as List<int>;
        
        var request = http.MultipartRequest('POST', Uri.parse('$baseUrl/upload'));
        request.files.add(http.MultipartFile.fromBytes('file', bytes, filename: file.name));

        try {
          var response = await request.send();
          if (response.statusCode == 200) {
            setState(() => _chatResponse = "جزوه با موفقیت پردازش شد! حالا می‌توانید سوال بپرسید.");
          }
        } catch (err) {
          setState(() => _chatResponse = "خطا در آپلود فایل.");
        } finally {
          setState(() => _isLoading = false);
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("RagAI", style: TextStyle(fontWeight: FontWeight.bold)),
          centerTitle: true,
          backgroundColor: Colors.white,
          foregroundColor: Colors.black87,
          elevation: 0,
          actions: [
            IconButton(
              icon: const Icon(Icons.upload_file, color: Color(0xFFC5A3FF)),
              onPressed: _pickAndUploadFile,
              tooltip: "آپلود جزوه PDF",
            )
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Expanded(
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    boxShadow: [
                      BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 5))
                    ],
                  ),
                  child: SingleChildScrollView(
                    child: Text(
                      _chatResponse,
                      style: const TextStyle(fontSize: 16, height: 1.8, color: Colors.black87),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: TextField(
                        controller: _controller,
                        decoration: const InputDecoration(
                          hintText: "سوال خود را بنویسید...",
                          border: InputBorder.none,
                        ),
                        onSubmitted: (_) => _sendMessage(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  ElevatedButton(
                    onPressed: _isLoading ? null : _sendMessage,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFC5A3FF),
                      foregroundColor: Colors.black87,
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 18),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                      elevation: 0,
                    ),
                    child: _isLoading 
                        ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black54))
                        : const Text("ارسال", style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}