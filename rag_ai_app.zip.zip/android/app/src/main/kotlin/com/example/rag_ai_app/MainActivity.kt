package com.example.rag_ai_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
